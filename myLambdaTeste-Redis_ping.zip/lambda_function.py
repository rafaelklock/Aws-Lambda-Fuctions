import json
import redis



def lambda_handler(event, context):

    try:
        conn = redis.StrictRedis(
            host='redis-host',
            port=16379,
            password='senha#'
            )
        print(conn)
        ping = conn.ping()
        print('Connected!')
    except Exception as ex:
        print('Error:', ex)
        exit('Failed to connect, terminating.')

    
    
    return {
        'statusCode': 200,
        'redis': json.dumps(ping)
    }
